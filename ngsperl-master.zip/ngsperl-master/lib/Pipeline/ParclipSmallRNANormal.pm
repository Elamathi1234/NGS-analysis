#!/usr/bin/perl
package Pipeline::ParclipSmallRNANormal;

use strict;
use warnings;
use CQS::FileUtils;
use CQS::SystemUtils;
use CQS::ConfigUtils;
use CQS::ClassFactory;
use Pipeline::PipelineUtils;
use Pipeline::SmallRNAUtils;
use Data::Dumper;
use Hash::Merge qw( merge );

require Exporter;
our @ISA = qw(Exporter);

our %EXPORT_TAGS = ( 'all' => [qw(getParclipSmallRNANormalConfig performParclipSmallRNANormal performParclipSmallRNANormalTask)] );

our @EXPORT = ( @{ $EXPORT_TAGS{'all'} } );

our $VERSION = '0.01';

sub getParclipSmallRNANormalConfig {
  my ($def) = @_;

  initDefaultValue( $def, "search_smallrna",                 1 );
  initDefaultValue( $def, "search_3utr",                     1 );
  initDefaultValue( $def, "exclude_smallrna_reads_for_3utr", 1 );
  initDefaultValue( $def, "gsnap_option", '-y 0 -z 0 -Y 0 -Z 0 -m 1 -Q --max-anchors 1 --use-shared-memory 0 --nofails --trim-mismatch-score 0 --trim-indel-score 0 --mode ttoc-nonstranded --gunzip' );
  initDefaultValue( $def, "gsnap_smallRNA_count_option",        '-s -e 4 --ignoreNTAAndNoPenaltyMutation ' );
  initDefaultValue( $def, "gsnap_3utr_count_option",            '-s -e 4 --noCategory --ignoreNTAAndNoPenaltyMutation ' );
  initDefaultValue( $def, "perform_class_independent_analysis", 0 );
  initDefaultValue( $def, "paralyzer_bowtie1_option",           "-v 2 -m 10 --best --strata" );
  initDefaultValue( $def, "output_to_same_folder",              1 );
  initDefaultValue( $def, "mappedonly",                         1 );

  if ( !$def->{search_smallrna} ) {
    $def->{"consider_miRNA_NTA"} = 0;
    $def->{"consider_tRNA_NTA"}  = 0;
  }

  my ( $config, $individual_ref, $summary_ref, $cluster, $source_ref, $preprocessing_dir, $class_independent_dir, $identical_ref ) = getPrepareConfig( $def, 1 );
  my @individual = @{$individual_ref};
  my @summary    = @{$summary_ref};

  my $groups            = $def->{groups};
  my $groups_vis_layout = $def->{groups_vis_layout};

  if ( defined $groups ) {
    if ( !defined $def->{tRNA_vis_group} ) {
      $def->{tRNA_vis_group} = $groups;
    }
  }

  my $t2c_dir = create_directory_or_die( $def->{target_dir} . "/t2c" );

  my $gsnap = {
    gsnap => {
      class                 => 'Alignment::Gsnap',
      perform               => 1,
      target_dir            => $t2c_dir . '/gsnap',
      option                => $def->{gsnap_option},
      gsnap_index_directory => $def->{gsnap_index_directory},
      gsnap_index_name      => $def->{gsnap_index_name},
      source_ref            => $identical_ref,
      sh_direct             => 0,
      cluster               => $cluster,
      pbs                   => {
        'email'    => $def->{email},
        'nodes'    => '1:ppn=' . $def->{max_thread},
        'walltime' => '72',
        'mem'      => '80gb'
      }
    }
  };
  push @individual, ('gsnap');

  if ( $def->{search_smallrna} ) {
    my $coor;
    if ( getValue( $def, "mirna_only", 1 ) ) {
      $coor = $def->{miRNA_coordinate};
    }
    else {
      $coor = $def->{coordinate};
    }
    $gsnap = merge(
      $gsnap,
      {
        gsnap_smallRNA_count => {
          class           => 'CQS::SmallRNACount',
          perform         => 1,
          target_dir      => $t2c_dir . '/gsnap_smallRNA_count',
          option          => $def->{"gsnap_smallRNA_count_option"},
          source_ref      => 'gsnap',
          seqcount_ref    => [ 'identical', '.dupcount$' ],
          coordinate_file => $coor,
          fasta_file      => $def->{coordinate_fasta},
          sh_direct       => 0,
          cluster         => $cluster,
          pbs             => {
            'email'    => $def->{email},
            'walltime' => '72',
            'mem'      => '40gb',
            'nodes'    => '1:ppn=1'
          },
        },
        gsnap_smallRNA_table => {
          class      => "CQS::SmallRNATable",
          perform    => 1,
          target_dir => $t2c_dir . "/gsnap_smallRNA_table",
          option     => "",
          source_ref => [ "gsnap_smallRNA_count", ".mapped.xml" ],
          prefix     => "smallRNA_parclip_",
          sh_direct  => 1,
          cluster    => $cluster,
          pbs        => {
            "email"    => $def->{email},
            "nodes"    => "1:ppn=1",
            "walltime" => "10",
            "mem"      => "10gb"
          },
        },
        gsnap_smallRNA_info => {
          class      => "CQS::CQSDatatable",
          perform    => 1,
          target_dir => $t2c_dir . "/gsnap_smallRNA_table",
          option     => "",
          source_ref => [ "gsnap_smallRNA_count", ".info" ],
          prefix     => "smallRNA_parclip_",
          suffix     => ".mapped",
          sh_direct  => 1,
          cluster    => $cluster,
          pbs        => {
            "email"     => $def->{email},
            "emailType" => $def->{emailType},
            "nodes"     => "1:ppn=1",
            "walltime"  => "10",
            "mem"       => "10gb"
          },
        },

        gsnap_smallRNA_category => {
          class      => "CQS::SmallRNACategory",
          perform    => 1,
          target_dir => $t2c_dir . "/gsnap_smallRNA_category",
          option     => "",
          source_ref => [ "gsnap_smallRNA_count", ".info\$" ],
          sh_direct  => 1,
          cluster    => $cluster,
          pbs        => {
            "email"    => $def->{email},
            "nodes"    => "1:ppn=1",
            "walltime" => "72",
            "mem"      => "40gb"
          },
        },
        gsnap_smallRNA_t2c => {
          class      => "CQS::ParclipT2CFinder",
          perform    => 1,
          target_dir => $t2c_dir . "/gsnap_smallRNA_t2c",
          option     => "-p 0.05 -e 0.013",
          source_ref => [ "gsnap_smallRNA_count", ".mapped.xml\$" ],
          sh_direct  => 1,
          pbs        => {
            "email"    => $def->{email},
            "nodes"    => "1:ppn=1",
            "walltime" => "72",
            "mem"      => "20gb"
          },
        },
        gsnap_smallRNA_t2c_summary => {
          class      => 'SmallRNA::T2CSummary',
          perform    => 1,
          target_dir => $t2c_dir . '/gsnap_smallRNA_t2c_table',
          option     => '',
          source_ref => [ 'gsnap_smallRNA_count', '.mapped.xml$' ],
          sh_direct  => 0,
          cluster    => $cluster,
          pbs        => {
            'email'    => $def->{email},
            'walltime' => '72',
            'mem'      => '40gb',
            'nodes'    => '1:ppn=1'
          },
        },
      }
    );
    
    if ( defined $config->{identical_check_cca} ) {
      $gsnap->{gsnap_smallRNA_count}{cca_files_ref} = ["identical_check_cca"];
    }

    push @individual, ( 'gsnap_smallRNA_count', 'gsnap_smallRNA_t2c' );
    push @summary, ( 'gsnap_smallRNA_table', 'gsnap_smallRNA_info', 'gsnap_smallRNA_category', 'gsnap_smallRNA_t2c_summary' );

    if ( defined $groups or defined $def->{tRNA_vis_group} ) {
      my $trna_vis_groups;
      if ( defined $def->{tRNA_vis_group} ) {
        $trna_vis_groups = $def->{tRNA_vis_group};
      }
      else {
        $trna_vis_groups = $groups;
      }

      addPositionVis(
        $config, $def,
        $summary_ref,
        "gsnap_tRNA_PositionVis",
        $t2c_dir,
        {
          output_file        => ".tRNAAnticodonPositionVis",
          output_file_ext    => ".tRNAAnticodonPositionVis.png",
          parameterFile1_ref => [ "gsnap_smallRNA_table", ".tRNA.count.position\$" ],
          parameterFile2_ref => [ "gsnap_smallRNA_info", ".mapped.count\$" ],
        }
      );
    }
  }
  $config = merge( $config, $gsnap );

  if ( $def->{search_3utr} ) {
    ( defined $def->{utr3_db} ) or die "utr3_db should be defined with search_3utr for parclip data analysis.";
    ( -e $def->{utr3_db} ) or die "utr3_db defined but not exists : " . $def->{utr3_db};

    my $exclude_ref;
    if ( $def->{search_smallrna} && $def->{"exclude_smallrna_reads_for_3utr"} ) {
      $exclude_ref = [ 'gsnap_smallRNA_count', ".xml" ];
    }
    else {
      $exclude_ref = undef;
    }

    my $utr3 = {
      gsnap_3utr_count => {
        class           => 'CQS::SmallRNACount',
        perform         => 1,
        target_dir      => $t2c_dir . '/gsnap_3utr_count',
        option          => $def->{gsnap_3utr_count_option},
        source_ref      => 'gsnap',
        seqcount_ref    => [ 'identical', '.dupcount$' ],
        exclude_xml_ref => $exclude_ref,
        coordinate_file => $def->{utr3_db},
        sh_direct       => 0,
        cluster         => $cluster,
        pbs             => {
          'email'    => $def->{email},
          'walltime' => '72',
          'mem'      => '40gb',
          'nodes'    => '1:ppn=1'
        },
      },
      gsnap_3utr_count_table => {
        class      => "CQS::SmallRNATable",
        perform    => 1,
        target_dir => $t2c_dir . "/gsnap_3utr_count_table",
        option     => "--noCategory",
        source_ref => [ "gsnap_3utr_count", ".mapped.xml" ],
        prefix     => "smallRNA_3utr_",
        sh_direct  => 1,
        cluster    => $cluster,
        pbs        => {
          "email"    => $def->{email},
          "nodes"    => "1:ppn=1",
          "walltime" => "10",
          "mem"      => "10gb"
        },
      }
    };
    push( @individual, "gsnap_3utr_count" );
    push( @summary,    "gsnap_3utr_count_table" );

    if ( defined $def->{seed_smallrna_fasta} ) {
      $utr3 = merge(
        $utr3,
        {
          gsnap_3utr_count_target_fasta => {
            class        => "CQS::ParclipTarget",
            perform      => 1,
            target_dir   => $t2c_dir . "/gsnap_3utr_count_target_fasta",
            option       => "",
            source_ref   => [ "gsnap_3utr_count", ".xml\$" ],
            seed         => $def->{seed_smallrna_fasta},
            fasta_file   => $def->{fasta_file},
            refgene_file => $def->{refgene_file},
            sh_direct    => 1,
            pbs          => {
              "email"    => $def->{email},
              "nodes"    => "1:ppn=1",
              "walltime" => "72",
              "mem"      => "20gb"
            },
          },
        }
      );

      push( @individual, ("gsnap_3utr_count_target_fasta") );

    }
    elsif ( $def->{search_smallrna} ) {

      $utr3 = merge(
        $utr3,
        {
          gsnap_3utr_count_target_t2c => {
            class        => "CQS::ParclipTarget",
            perform      => 1,
            target_dir   => $t2c_dir . "/gsnap_3utr_count_target_t2c",
            option       => "",
            source_ref   => [ "gsnap_3utr_count", ".xml\$" ],
            seed_ref     => [ "gsnap_smallRNA_t2c", ".xml\$" ],
            fasta_file   => $def->{fasta_file},
            refgene_file => $def->{refgene_file},
            sh_direct    => 1,
            pbs          => {
              "email"    => $def->{email},
              "nodes"    => "1:ppn=1",
              "walltime" => "72",
              "mem"      => "20gb"
            },
          },

          gsnap_3utr_count_target_all => {
            class        => "CQS::ParclipTarget",
            perform      => 1,
            target_dir   => $t2c_dir . "/gsnap_3utr_count_target_all",
            option       => "",
            source_ref   => [ "gsnap_3utr_count", ".xml\$" ],
            seed_ref     => [ "gsnap_smallRNA_count", ".mapped.xml\$" ],
            fasta_file   => $def->{fasta_file},
            refgene_file => $def->{refgene_file},
            sh_direct    => 1,
            pbs          => {
              "email"    => $def->{email},
              "nodes"    => "1:ppn=1",
              "walltime" => "72",
              "mem"      => "20gb"
            },
          },
        }
      );

      push( @individual, ( "gsnap_3utr_count_target_t2c", "gsnap_3utr_count_target_all" ) );
    }
    $config = merge( $config, $utr3 );
  }

  if ( defined $def->{search_specific_range} && $def->{search_specific_range} ) {
    ( defined $def->{specific_range_bed} ) or die "specific_range_bed should be defined with search_specific_range for parclip data analysis.";
    ( -e $def->{specific_range_bed} ) or die "specific_range_bed defined but not exists : " . $def->{specific_range_bed};

    my $specific = {
      gsnap_specific_range_count => {
        class           => 'CQS::SmallRNACount',
        perform         => 1,
        target_dir      => $t2c_dir . '/gsnap_specific_range_count',
        option          => '-s -e 4 --noCategory',
        source_ref      => 'gsnap',
        seqcount_ref    => [ 'identical', '.dupcount$' ],
        exclude_xml_ref => [ 'gsnap_smallRNA_count', ".xml" ],
        coordinate_file => $def->{specific_range_bed},
        sh_direct       => 0,
        cluster         => $cluster,
        pbs             => {
          'email'    => $def->{email},
          'walltime' => '72',
          'mem'      => '40gb',
          'nodes'    => '1:ppn=1'
        },
      },
      gsnap_specific_range_count_table => {
        class      => "CQS::SmallRNATable",
        perform    => 1,
        target_dir => $t2c_dir . "/gsnap_specific_range_count_table",
        option     => "--noCategory",
        source_ref => [ "gsnap_specific_range_count", ".mapped.xml" ],
        prefix     => "parclip_specific_range_",
        sh_direct  => 1,
        cluster    => $cluster,
        pbs        => {
          "email"    => $def->{email},
          "nodes"    => "1:ppn=1",
          "walltime" => "10",
          "mem"      => "10gb"
        },
      },
    };

    push( @individual, ("gsnap_specific_range_count") );
    push( @summary, "gsnap_specific_range_count_table" );
    $config = merge( $config, $specific );
  }

  if ( $def->{perform_paralyzer} ) {
    my $paralyzer_dir = create_directory_or_die( $def->{target_dir} . "/paralyzer" );
    my $bowtie_task =
      addBowtie1PARalyzer( $config, $def, \@individual, "bowtie_paralyzer", $paralyzer_dir, getValue( $def, "paralyzer_bowtie1_index" ), $source_ref, getValue( $def, "paralyzer_bowtie1_option" ) );
  }

  $config->{sequencetask} = {
    class      => getSequenceTaskClassname($cluster),
    perform    => 1,
    target_dir => $def->{target_dir} . '/sequencetask',
    option     => '',
    source     => {
      step1 => \@individual,
      step2 => \@summary,
    },
    sh_direct => 0,
    cluster   => 'slurm',
    pbs       => {
      'email'    => $def->{email},
      'nodes'    => '1:ppn=' . $def->{max_thread},
      'walltime' => '72',
      'mem'      => '40gb'
    },
  };

  return ($config);
}

sub performParclipSmallRNANormal {
  my ( $def, $perform ) = @_;
  if ( !defined $perform ) {
    $perform = 1;
  }

  my $config = getParclipSmallRNANormalConfig($def);

  if ($perform) {
    saveConfig( $def, $config );

    performConfig($config);
  }

  return $config;
}

sub performParclipSmallRNANormalTask {
  my ( $def, $task ) = @_;

  my $config = getParclipSmallRNANormalConfig($def);

  performTask( $config, $task );

  return $config;
}

1;
