library(dplyr)
library(reshape2)
library(ggplot2)

options(bitmapType='cairo')

draw_vcf_chromosome_count(parSampleFile1, outFile)
