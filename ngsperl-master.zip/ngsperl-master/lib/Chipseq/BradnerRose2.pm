#!/usr/bin/perl
package Chipseq::BradnerRose2;

use strict;
use warnings;
use Chipseq::Rose2;

our @ISA = qw(Chipseq:Rose2);

1;
